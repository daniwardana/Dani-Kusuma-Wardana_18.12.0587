package com.muhammadwahyudin.kadefootballapp.data.remote.response

import com.muhammadwahyudin.kadefootballapp.data.model.Team

data class TeamsRes(
    val teams: List<Team>
)